package com.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProductProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProductProjectApplication.class, args);
	}

}
