package com.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProductProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
