package com.oProcess.mngnt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderProcessManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
